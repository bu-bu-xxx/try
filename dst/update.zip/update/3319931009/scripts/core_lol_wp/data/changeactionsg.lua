---@diagnostic disable: lowercase-global, undefined-global, trailing-space

---@type data_changeactionsg[]
local data = {
    -- {
    --     action = 'BUILD',
    --     sg = 'doshortaction',
    --     testfn = function (doer)
    --         return doer and doer:HasTag("player")
    --     end,
    --     testfn_client = function (doer)
    --         return doer and doer:HasTag("player")
    --     end
    -- }
}
return data