---@diagnostic disable: lowercase-global, undefined-global, trailing-space

---@type data_attackperiod
local data = {
}

return data