name = "Frosty Friends: Meet Frostlet"
author = "Asura, 󰀣POWD3d4󰀣"
version = "1.0"
local info_version = "󰀔 [ Version "..version.." ]\n"

description = info_version..[[ Frostlet is an ice pet that brings unique magic to the world of Don't Starve Together. This adorable yet fearsome Deerclops, adorned in its icy coat, can not only beautify the environment but also protect its owner from the biting cold. Frostlet has a single bright eye that sparkles like a star in the night sky, with antlers covered in frost and snowflakes. This pet will follow you on all your adventures, leaving a trail of frost in its wake. ]]

forumthread = ""

api_version = 10

dst_compatible = true

dont_starve_compatible = false
reign_of_giants_compatible = false
shipwrecked_compatible = false

all_clients_require_mod = true 

icon_atlas = "images/modicon.xml"
icon = "modicon.tex"

server_filter_tags = {
    "character",
}
