
return function(inst)

    if not TheWorld.ismastersim then
        return
    end

end