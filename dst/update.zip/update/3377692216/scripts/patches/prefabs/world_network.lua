return function(inst)
end
