local prefabs = {}
local groupid = 420

table.insert(prefabs, CreatePrefabSkin("ms_fawnclops_yule", {
	assets = {
		Asset("DYNAMIC_ANIM", "anim/dynamic/ms_fawnclops_yule.zip"),
		Asset("PKGREF", "anim/dynamic/ms_fawnclops_yule.dyn"),
	},
	base_prefab = "critter_fawnclops",
	build_name_override = "ms_fawnclops_yule",
	type = "item",
	rarity = "ModMade",

	skin_tags = { "PET", "YULE", "CRAFTABLE", },
	release_group = groupid,
}))

table.insert(prefabs, CreatePrefabSkin("ms_fawnclops_yule_builder", {
	assets = {
		Asset("DYNAMIC_ANIM", "anim/dynamic/ms_fawnclops_yule.zip"),
		Asset("PKGREF", "anim/dynamic/ms_fawnclops_yule.dyn"),
	},
	base_prefab = "critter_fawnclops_builder",
	build_name_override = "ms_fawnclops_yule",
	type = "item",
	rarity = "ModMade",

	skin_tags = { },
	release_group = groupid,
}))

return unpack(prefabs)