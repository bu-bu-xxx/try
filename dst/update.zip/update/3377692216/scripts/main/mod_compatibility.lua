local KnownModIndex = GLOBAL.KnownModIndex
local STRINGS = GLOBAL.STRINGS

-- Uncompromising Mode
if TUNING.RT_UNCOMP and MOD.UNCOMP_ENABLED then
	modimport("scripts/main/mods/uncomp")
end
