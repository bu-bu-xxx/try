local strings =
{
    NAMES =
    {
        CRITTER_FAWNCLOPS = "Frostlet",
        CRITTER_FAWNCLOPS_BUILDER = "Frostlet",
    },

    SKIN_NAMES =
    {
        critter_fawnclops = "Frostlet",
        critter_fawnclops_yule = "Yule",
    },

    RECIPE_DESC =
    {
        CRITTER_FAWNCLOPS_BUILDER = "Befriend a frosty Frostlet",
    },

    CHARACTERS = 
    {
        GENERIC = 
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "What a peculiar little creature! I wonder if it's as cold on the outside as it is on the inside.",
            } 
        },

        WILLOW =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "Such a tiny monster! I bet it would look cute with a little flame on its head.",
            },
        },
        WOLFGANG =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "A baby giant? I can handle it with one hand! But, look at its tiny feet!",
            },
        },
        WENDY =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "This little Frostlet looks like it could freeze my heart... or just my hands!",
            },
        },
        WX78 =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "CUTENESS LEVEL: CRITICAL! MUST CALCULATE OPTIMAL CUDDLE SETTINGS",
            },
        },
        WICKERBOTTOM =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "What an intriguing specimen! I'll need to study its behavior and habits.",
            },
        },
        WOODIE =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "Look at its little waddle! It's as if frost itself decided to become a pet!",
            },
        },
        WAXWELL =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "What's this? A miniature beast? I suppose every cold heart needs a companion.",
            },
        },
        WATHGRITHR =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "A tiny warrior! I shall protect this little creature with my life!",
            },
        },
        WEBBER =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "Oh wow, a little Deerclops! I wonder if it likes spiders as friends?",
            },
        },
        WINONA =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "This little one could be a great helper, as long as it doesn't freeze my tools!",
            },
        },
        WARLY =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "Imagine the dishes I could cook with this little guy's ice! Culinary magic!",
            },
        },
        WORTOX =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "A tiny Frostlet! It seems perfect for a mischievous prank!",
            },
        },
        WORMWOOD =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "A tiny friend made of ice! So delicate, I must be gentle!",
            },
        },
        WURT =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "A little Ice Monster! He's not scary at all, just cute!",
            },
        },
        WALTER =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "Look at that little Frostlet! It's like a miniature adventurer!",
            },
        },
        WANDA =
        {
            DESCRIBE = {
                CRITTER_FAWNCLOPS = "This tiny Frostlet has a certain charm. It's like carrying a piece of winter with me!",
            },
        },
    },
}

TransferTable(strings, STRINGS)
