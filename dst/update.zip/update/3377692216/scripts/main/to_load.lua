return {
	Prefabs = {	
		"critter_fawnclops",
		"fawnclops_skins",
	},

	Assets = {
		Asset("ATLAS", "images/invimages_fawnclops.xml"),
		Asset("IMAGE", "images/invimages_fawnclops.tex"),
		Asset("ATLAS_BUILD", "images/invimages_fawnclops.xml", 256),
	},

	MiniMaps = {
	},
	
	
}
