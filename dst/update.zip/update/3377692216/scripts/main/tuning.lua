
local seg_time = 30
local total_day_time = seg_time*16

local day_segs = 10
local dusk_segs = 4
local night_segs = 2

--default day composition. changes in winter, etc
local day_time = seg_time * day_segs
local dusk_time = seg_time * dusk_segs
local night_time = seg_time * night_segs

local multiplayer_attack_modifier = 1--0.6--0.75
local multiplayer_goldentool_modifier = 1--0.5--0.75
local multiplayer_armor_durability_modifier = 0.7
local multiplayer_armor_absorption_modifier = 1--0.75
local multiplayer_wildlife_respawn_modifier = 1--2

local wilson_attack = 34 * multiplayer_attack_modifier
local wilson_health = 150
local wilson_hunger = 150
local wilson_sanity = 200
local calories_per_day = 75

local wilson_attack_period = 0.4 --prevents players

local tunings = {
}


TransferTable(tunings, TUNING)
