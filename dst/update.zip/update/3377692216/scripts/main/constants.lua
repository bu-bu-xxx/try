--- Mods
GLOBAL.MOD = {
    UNCOMP_ENABLED = GLOBAL.KnownModIndex:IsModEnabled("workshop-2039181790"),
}

GLOBAL.MATERIALS.GOLDNUGGET = "goldnugget"
