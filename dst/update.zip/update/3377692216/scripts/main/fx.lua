local _fx = require("fx")

local fx = {
   
}

for k, v in ipairs(fx) do
    table.insert(_fx, v)
end