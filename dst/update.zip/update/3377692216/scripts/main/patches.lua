local env = env
local KnownModIndex = KnownModIndex
local AddBrainPostInit = AddBrainPostInit
local AddStategraphPostInit = AddStategraphPostInit
local AddPrefabPostInit = AddPrefabPostInit
local AddComponentPostInit = AddComponentPostInit
local AddStategraphState = AddStategraphState
local AddGlobalClassPostConstruct = AddGlobalClassPostConstruct
local AddClassPostConstruct = AddClassPostConstruct
local AddPlayerPostInit = AddPlayerPostInit
local AddPrefabPostInitAny = AddPrefabPostInitAny
local AddSimPostInit = AddSimPostInit
_G.setfenv(1, _G)


local GenericPlayerFn = require("patches/prefabs/player")
local AnyFn = require("patches/prefabs/any")

local PATCHES = 
{
	COMPONENTS = {
		
	},

	REPLICAS = {

	},
	PREFABS = {	},
	PLAYERS = {
	},

	STATEGRAPHS = {},
	STATES = {},
	BRAINS = {
	},
	WIDGETS = {
	},
	SCREENS = {
	},
}

local network_postinits = {}
local done_inits = {}

local _MakeWorldNetwork = require("prefabs/world_network")
local function MakeWorldNetwork(...)
	local inst = _MakeWorldNetwork(...)
	local prefab = inst.prefab or inst.name

	if not done_inits[prefab] then
		done_inits[prefab] = true
		AddPrefabPostInit(prefab, function(inst)
			for _, v in ipairs(network_postinits) do
				v(inst)
			end
		end)
	end

	return inst
end
package.loaded["prefabs/world_network"] = MakeWorldNetwork

function AddNetworkPostInit(fn)
	table.insert(network_postinits, fn)
end

env.AddNetworkPostInit = AddNetworkPostInit
local GenericNetworkFn = require("patches/prefabs/world_network")
AddNetworkPostInit(GenericNetworkFn)


for i, prefab in ipairs(PATCHES.PLAYERS) do
	PATCHES.PREFABS[prefab] = prefab
end

local function patch(prefab, fn)
	AddPrefabPostInit(prefab, fn)
end
	
for path, data in pairs(PATCHES.PREFABS) do
	local fn = require("patches/prefabs/"..path)
	
	if type(data) == "string" then
		patch(data, function(inst) fn(inst, data) end)
	else
		for _, pref in ipairs(data) do
			patch(pref, function(inst) fn(inst, pref) end)
		end
	end
end

AddPlayerPostInit(GenericPlayerFn)
AddPrefabPostInitAny(AnyFn)

for _, name in ipairs(PATCHES.STATEGRAPHS) do
	AddStategraphPostInit(name, require("patches/stategraphs/"..name))
end

local function patchbrain(prefab, fn)
	if softresolvefilepath("scripts/brains/"..prefab..".lua") then
		AddBrainPostInit(prefab, fn)
	end
end

local function patchclass(prefab, fn)
	AddClassPostConstruct(prefab, fn)
end

for path, data in pairs(PATCHES.BRAINS) do
	local fn = require("patches/brains/"..path)
	
	if type(data) == "string" then
		patchbrain(data, function(inst) fn(inst, data) end)
	else
		for _, pref in ipairs(data) do
			patchbrain(pref, function(inst) fn(inst, pref) end)
		end
	end
end

for _, file in ipairs(PATCHES.COMPONENTS) do
	local fn = require("patches/components/"..file)
	AddComponentPostInit(file, fn)
end

for _, file in ipairs(PATCHES.REPLICAS) do
	local fn = require("patches/components/"..file.."_replica")
	patchclass("components/"..file.."_replica", fn)
end

for _, file in ipairs(PATCHES.WIDGETS) do
	local fn = require("patches/widgets/"..file)
	patchclass("widgets/"..file, fn)
end

for _, file in ipairs(PATCHES.SCREENS) do
	local fn = require("patches/screens/"..file)
	patchclass("screens/"..file, fn)
end


for _, file in ipairs(PATCHES.STATES) do
	local server_states = require("patches/states/"..file)
	for i, state in ipairs(server_states) do
		AddStategraphState(file, state)
	end
end
