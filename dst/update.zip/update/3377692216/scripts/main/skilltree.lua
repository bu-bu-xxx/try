-- local SkillTreeDefs = require("prefabs/skilltree_defs")

-- local CreateSkillTree = function()
-- 	local BuildSkillsData = require("prefabs/skilltree_wose")

--     if BuildSkillsData then
--         local data = BuildSkillsData(SkillTreeDefs.FN)

--         if data then
--             SkillTreeDefs.CreateSkillTreeFor("wose", data.SKILLS)
--             SkillTreeDefs.SKILLTREE_ORDERS["wose"] = data.ORDERS
--         end
--     end
-- end
-- CreateSkillTree()

-- RegisterSkilltreeBGForCharacter("images/wose_skilltree.xml", "wose")
-- local skilltree = require("prefabs/skilltree_wose")
-- if skilltree then
--     skilltree = skilltree()
--     for k, v in pairs(skilltree.SKILLS) do
--         if v and v.icon then
--             RegisterSkilltreeIconsAtlas("images/woseskilltree_icons.xml", v.icon..".tex")
--         end
--     end
-- end