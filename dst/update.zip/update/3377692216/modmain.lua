GLOBAL.setmetatable(env,{__index=function(t,k) return GLOBAL.rawget(GLOBAL,k) end})

local require = GLOBAL.require
local STRINGS = GLOBAL.STRINGS
local containers = require "containers"
local AddModRPCHandler = AddModRPCHandler
local modname = modname


local ToLoad = require("main/to_load")
PrefabFiles = ToLoad.Prefabs
Assets = ToLoad.Assets
for k, v in ipairs(ToLoad.MiniMaps) do
    AddMinimapAtlas(v)
end

GLOBAL.UpvalueHacker = require("tools/upvaluehacker")

modimport("scripts/main/rpc.lua")
modimport("scripts/main/utils.lua")
modimport("scripts/main/constants.lua")
modimport("scripts/main/tuning.lua")
modimport("scripts/main/strings.lua")
modimport("scripts/main/recipes.lua")
modimport("scripts/main/patches.lua")
modimport("scripts/main/characters.lua")
modimport("scripts/main/fx.lua")
modimport("scripts/main/mod_compatibility.lua")
modimport("scripts/main/skilltree.lua")

local env = env
local modimport = modimport
_G.setfenv(1, _G)

local tex = {
	"ms_fawnclops_yule",
}

for k, v in pairs(tex) do
	RegisterInventoryItemAtlas(resolvefilepath("images/invimages_fawnclops.xml"), v..".tex")
end

ITEM_DISPLAY_BLACKLIST.ms_fawnclops_yule_builder = true

critter_fawnclops_builder_init_fn = function(inst, build_name) critter_builder_init_fn( inst, build_name ) end
critter_fawnclops_builder_clear_fn = function(inst) inst.linked_skinname = nil end

critter_fawnclops_init_fn = function(inst, build_name)
	pet_init_fn(inst, build_name, "fawnclops_build") 
end
critter_fawnclops_clear_fn = function(inst) 
    inst.linked_skinname = nil
end

if env.is_mim_enabled then 
	return 
end 
