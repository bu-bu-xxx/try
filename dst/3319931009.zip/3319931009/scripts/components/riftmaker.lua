local Riftmaker = Class(function(self, inst)
    self.inst = inst

    self.form = nil
end)

return Riftmaker