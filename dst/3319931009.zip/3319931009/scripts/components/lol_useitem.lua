local lol_useitem = Class(function(self, inst)
    self.inst = inst
end)

return lol_useitem