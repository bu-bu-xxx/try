--单纯绑定动作用
local gallop_chop =
    Class(
    function(self, inst)
        self.inst = inst
    end
)

return gallop_chop
