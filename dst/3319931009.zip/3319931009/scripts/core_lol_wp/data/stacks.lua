---@type data_stack
local data = {
    -- goldnugget = 45,
    -- flint = 23,
}

return data