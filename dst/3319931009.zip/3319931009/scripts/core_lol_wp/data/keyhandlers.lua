---@diagnostic disable: lowercase-global, undefined-global, trailing-space

---@type data_keyhandler[]
local data = {

}


return data