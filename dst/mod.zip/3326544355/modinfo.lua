name = "霓虹唱片"
description = [[

]]
author = "锡徐、绯世行"
version = "1.0.4"

forumthread = ""

api_version = 10

priority = -100

dst_compatible = true
all_clients_require_mod = true

dont_starve_compatible = false
reign_of_giants_compatible = false
shipwrecked_compatible = false

icon_atlas = "images/modicon.xml"
icon = "modicon.tex"

server_filter_tags = {
    "record",
}

configuration_options = {
    {
        name = "phonograph_carry_play",
        label = "留声机带身上也可以播放",
        hover = "让留声机拾取后在身上也可以继续播放。",
        options = {
            { description = "开", data = true },
            { description = "关", data = false },
        },
        default = false,
    },
}
