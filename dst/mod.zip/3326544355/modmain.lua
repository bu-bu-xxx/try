GLOBAL.setmetatable(env, { __index = function(t, k) return GLOBAL.rawget(GLOBAL, k) end })

----------------------------------------------------------------------------------------------------
--[[
唱片mod教程：
https://n77a3mjegs.feishu.cn/docx/PdlOd0B3ho25Ffxhwh8cfXhVn5d?from=from_copylink

配置区：
需要配置的地方有两个，一个是Assets里的打包好的音乐文件路径，一个是每个音乐相关信息

参数说明：
{ "will", "fsx_pure_1/music/will", "Will(潘多拉之心)", "潘多拉之心番剧中我最喜欢的音乐。", "相信你肯定也会喜欢的。" }
1：用于决定预制件名，简单来说唯一不重复就行，也最好防止和其他唱片mod重复，为了方便我一般用歌曲的英文名或者拼音，并且一开始mp3文件就是这样命名的
2：音乐播放路径，在FmodDesigner文件里决定的
3：唱片的名字
4：唱片的检查描述
5：唱片的制作栏描述

注意：
暂停游戏音乐依然可以播放不是bug，解决不了。

]]


Assets = {
    Asset("SOUNDPACKAGE", "sound/neon.fev"), --打包的音乐文件
    Asset("SOUND", "sound/neon.fsb"),        --打包的音乐文件
}

local MY_RECORDS = {
    -- 不会重复的id，音乐路径，唱片物品名，唱片的检查描述，唱片的制作栏描述
    -- { "will", "fsx_pure_1/music/will", "Will(潘多拉之心)", "潘多拉之心番剧中我最喜欢的音乐。", "相信你肯定也会喜欢的。" },
}

for k, v in pairs({
    miqi = "米奇go",
    nailong = "我是奶龙"
}) do
    table.insert(MY_RECORDS, { "neno_" .. k, "neon/music/" .. k, v })
end








----------------------------------------------------------------------------------------------------
PrefabFiles = {
    "neon_records"
}

table.insert(Assets, Asset("ATLAS", "images/neon_record.xml"))

STRINGS.UI.CRAFTING_FILTERS.NEON_RECORD = "唱片"

local PHONOGRAPH_CARRY_PLAY = GetModConfigData("phonograph_carry_play") --留声机拾取时继续播放

TUNING.NEON_RECORDS = TUNING.NEON_RECORDS or {}
ConcatArrays(TUNING.NEON_RECORDS, MY_RECORDS)


----------------------------------------------------------------------------------------------------
local OnLosePhonograph

local function ClearPlayerTag(owner)
    owner.SoundEmitter:KillSound("neon_ragtime")
    owner._neon_phonograph = nil
    owner:RemoveEventCallback("itemlose", OnLosePhonograph)
end

OnLosePhonograph = function(inst, data)
    if data and data.prev_item and data.prev_item == inst._neon_phonograph then
        ClearPlayerTag(inst)
    end
end

local function onremove(inst, data)
    local owner = inst.components.inventoryitem.owner
    if owner then
        ClearPlayerTag(owner)
    end
end

AddPrefabPostInit("phonograph", function(inst)
    if not TheWorld.ismastersim then return inst end

    inst.TurnOffMachine = function() end --为什么科雷设计成播放64秒就停止了？

    if PHONOGRAPH_CARRY_PLAY then
        local Oldonputininventoryfn = inst.components.inventoryitem.onputininventoryfn
        inst.components.inventoryitem.onputininventoryfn = function(inst, owner, ...)
            local song = inst:GetRecordSong()
            if song
                and inst.components.machine and inst.components.machine:IsOn()
                and owner and owner.SoundEmitter
            then
                ClearPlayerTag(owner)

                owner._neon_phonograph = inst
                owner.SoundEmitter:PlaySound(song, "neon_ragtime")
                owner:ListenForEvent("itemlose", OnLosePhonograph)
            end

            return Oldonputininventoryfn and Oldonputininventoryfn(inst, owner, ...)
        end

        inst:ListenForEvent("onremove", onremove)
    end
end)

----------------------------------------------------------------------------------------------------

-- 让纱耶香的唱片可以放进去
AddPrefabPostInitAny(function(inst)
    if not inst:HasTag("sayaka_record") then return end

    inst:AddTag("phonograph_record")

    if not TheWorld.ismastersim then return end

    if not inst.components.tradable then
        inst:AddComponent("tradable")
    end

    inst.songToPlay = inst.songToPlay or inst.recordSound --recordSound是老版本纱耶香
end)


-- 兼容烁码音乐，需要mod优先级尽量调低才能获取到
for k, songs in pairs(TUNING.SHUOMALISTMUSIC_EX or {}) do
    for i, d in ipairs(songs) do
        local name = k .. i
        table.insert(TUNING.NEON_RECORDS, { "neno_" .. name, d.path, d.name })
    end
end


----------------------------------------------------------------------------------------------------

if not CRAFTING_FILTERS.NEON_RECORD then
    AddRecipeFilter({
        name = "NEON_RECORD",
        atlas = resolvefilepath("images/neon_record.xml"),
        image = "neon_record.tex",
    })

    local TechTree = require("techtree")
    for _, recipe in pairs(AllRecipes) do
        for i, v in ipairs(TechTree.AVAILABLE_TECH) do
            recipe.level[v] = recipe.level[v] or 0
        end
    end
end

local function AddRecordRecipe(name)
    AddRecipe2(name, { Ingredient("batwing", 1), Ingredient("charcoal", 1) },
        TECH.NONE, {
            image = "record.tex",
        }, { "NEON_RECORD" })
end

for _, data in ipairs(TUNING.NEON_RECORDS) do
    AddRecordRecipe("neon_record_" .. data[1])
end
