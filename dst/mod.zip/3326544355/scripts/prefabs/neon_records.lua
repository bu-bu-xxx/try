local rets = {}
local record_fn = Prefabs["record"].fn
for _, data in ipairs(TUNING.NEON_RECORDS) do
    local upppername = string.upper("neon_record_" .. data[1])
    local displayname = data[3] or data[1]
    STRINGS.NAMES[upppername] = displayname
    STRINGS.CHARACTERS.GENERIC.DESCRIBE[upppername] = data[4] or displayname
    STRINGS.RECIPE_DESC[upppername] = data[5] or displayname

    local function fn(...)
        local inst = record_fn(...)

        if not TheWorld.ismastersim then
            return inst
        end

        inst.songToPlay = data[2]
        inst.components.inventoryitem:ChangeImageName("record")

        return inst
    end

    table.insert(rets, Prefab("neon_record_" .. data[1], fn))
end

return unpack(rets)
